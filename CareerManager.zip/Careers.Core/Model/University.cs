﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Careers.Core.Model {
    public class University {
        public string Name { get; set; }
        public string Country { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
